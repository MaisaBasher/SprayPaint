﻿using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SprayPaint
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private double sprayThickness;
        private double sprayOpacity;
        private Brush brushColor;
        private bool isErase;
        private bool isPaint;
        private DispatcherTimer timer;
        public MainWindow()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(100);
            timer.Tick += onTimerTick;
            sprayThickness = 1;
            sprayOpacity = .1;
            brushColor = Brushes.Black;
            isPaint = false;
           
        }
        /* 
         * Method Purpose: Upload Image 
        */
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image files|*.bmp;*.jpg;*.png;";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog() == true)
            {
                ImagePicture.Source = new BitmapImage(new Uri(ofd.FileName));
            }

        }

        /* 
         * Method Purpose: Spray paint
         * Logic: Create ellipse based on updated thickness , Opacity
        */
        private void sprayPaint(Brush color, Point position)
        {
            Ellipse paint = new Ellipse();
            paint.Fill = color;
            paint.Width = sprayThickness + 0.5;
            paint.Height = sprayThickness;
            paint.Opacity = sprayOpacity;
            paint.StrokeThickness = .2;
            Canvas.SetTop(paint, position.Y);
            Canvas.SetLeft(paint, position.X);
            paintCanvas.Children.Add(paint);
        }


        /* 
         * Method Purpose: Setting Color for brush 
        */
        private void col1_Click(object sender, RoutedEventArgs e)
        {
            brushColor = col1.Background;
            fincol.Fill = brushColor;
        }

        private void col2_Click(object sender, RoutedEventArgs e)
        {
            brushColor = col2.Background;
            fincol.Fill = brushColor;
        }

        private void col3_Click(object sender, RoutedEventArgs e)
        {
            brushColor = col3.Background;
            fincol.Fill = brushColor;
        }

        private void col4_Click(object sender, RoutedEventArgs e)
        {
            brushColor = col4.Background;
            fincol.Fill = brushColor;
        }

        private void col5_Click(object sender, RoutedEventArgs e)
        {
            brushColor = col5.Background;
            fincol.Fill = brushColor;
        }

        /* 
          * Method uPrpose: Activate spray Paint when mouse move in Image in active paint mode. 
         */

        private void ImagePicture_MouseMove(object sender, MouseEventArgs e)
        {
            if (isPaint)
            {
                Point mousePos = e.GetPosition(ImagePicture);
                sprayPaint(brushColor, mousePos);
            }
           
        }

        /* 
         * Method Purpose: active paint mode for different mouse event. 
        */
        private void ImagePicture_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isPaint = true;
        }

        private void ImagePicture_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            isPaint = true;   
        }

        private void ImagePicture_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isPaint = false;
        }

        private void ImagePicture_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            isPaint = false;
        }
        /* 
         * Method Purpose:  active paint mode & Time track start. 
        */
        private void ImagePicture_MouseDown(object sender, MouseButtonEventArgs e)
        { 
            isPaint = true;
            timer.Start(); 
        }
        /* 
         * Method Purpose:  end paint mode & Time track stop. 
        */
        private void ImagePicture_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isPaint = false;
            timer.Stop();
        }
        /* 
         * Method Purpose: incresing the spray effect when clicking on same position for some time
        */
        private void onTimerTick(object sender, EventArgs e)
        {
            Point mousePos = Mouse.GetPosition(ImagePicture);
            sprayThickness+= .5;
            sprayPaint(brushColor, mousePos);
        }
        /* 
         * Method Purpose: Save Image 
        */
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var imageSource = new RenderTargetBitmap(
                (int) paintCanvas.ActualWidth,
                (int) paintCanvas.ActualHeight,
                96, 96, PixelFormats.Pbgra32);

            //var imageSource = ImagePicture.Source as BitmapSource;
            imageSource.Render(paintCanvas);
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.DefaultExt = "jpg*";
            //saveFileDialog.FileName = ".jpg*";
            saveFileDialog.Filter = "jpg files (*.jpg)|*.jpg";
            if(saveFileDialog.ShowDialog() == true) {
                BitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(imageSource));
                using (var fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create))
                {
                    encoder.Save(fileStream);
                }
            }
        }
        /* 
         * Method Purpose:  Setting thickness of brush
        */

        private void thickness_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            sprayThickness = e.NewValue;
        }
        /* 
         * Method Purpose:  Setting opacity of brush
        */
        private void opacity_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            sprayOpacity = e.NewValue;
        }
        /* 
         * Method Prpose: Erase/clear Spray Paint 
        */
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            paintCanvas.Children.Clear();
            paintCanvas.Children.Add(ImagePicture);
        }
        
   
    }
}